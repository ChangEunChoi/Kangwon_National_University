package kr.ac.knu.cse.assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.hardware.input.InputManager;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int[] images = {0,R.drawable.image_1,R.drawable.image2,R.drawable.image3,R.drawable.image4,R.drawable.image5,R.drawable.image6,R.drawable.image7,R.drawable.image8,
            R.drawable.image9,R.drawable.image10,R.drawable.image11,R.drawable.image12,R.drawable.image13,R.drawable.image14,R.drawable.image15,R.drawable.image16,
            R.drawable.image17,R.drawable.image18,R.drawable.image19,R.drawable.image20,R.drawable.image21,R.drawable.image22,R.drawable.image23,R.drawable.image24,
            R.drawable.image25,R.drawable.image26,R.drawable.image27,R.drawable.image28,R.drawable.image29,R.drawable.image30};

    ImageView imageView;
    Button backButton;
    Button forwardButton;
    EditText editText;
    int num =  1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        backButton = findViewById(R.id.button1);
        forwardButton = findViewById(R.id.button2);
        editText = findViewById(R.id.editText);

        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                //키보드를 보이게 하든 숨기든 InputMethodManager객체 필요 이후 이 객체의 메소드를 이용해 원히는 작업 수행
                InputMethodManager imm = (InputMethodManager)getSystemService(Activity.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),0);
                String s = textView.getText().toString();
                //int edt_num = Integer.parseInt(s);
                //String test_s = Integer.toString(edt_num);
                //Toast.makeText(getApplicationContext(),test_s,Toast.LENGTH_LONG).show();
                float test_float = Float.parseFloat(s);
                //String test_s = Float.toString(test_float);
                //Toast.makeText(getApplicationContext(),test_s,Toast.LENGTH_LONG).show();
                int edtx_num = (int)Math.round(test_float);
                //textView.setText(Integer.toString(edtx_num));
                //String test_s = Integer.toString(edtx_num);
                //Toast.makeText(getApplicationContext(),test_s,Toast.LENGTH_LONG).show();
                if (edtx_num > 30) {
                    num = 30;
                    Toast.makeText(getApplicationContext(),"사진은 1~30까지만 있습니다.",Toast.LENGTH_LONG).show();
                } else if(edtx_num < 1) {
                    num = 1;
                    Toast.makeText(getApplicationContext(),"사진은 1~30까지만 있습니다.",Toast.LENGTH_LONG).show();
                } else {
                    num = edtx_num;
                }
                imageView.setImageResource(images[num]);
                editText.setText(""+num);
                return true;
            }
        });



        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num--;
                if(num < 1) {
                    num = 1;
                    Toast.makeText(getApplicationContext(),"사진은 1~30까지만 있습니다.",Toast.LENGTH_LONG).show();
                }
                imageView.setImageResource(images[num]);
                editText.setText(""+num);
            }
        });

        forwardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num++;
                if(num > 30) {
                    num = 30;
                    Toast.makeText(getApplicationContext(),"사진은 1~30까지만 있습니다.",Toast.LENGTH_LONG).show();

                }
                imageView.setImageResource(images[num]);
                editText.setText(""+num);
            }
        });

    }
}