package kr.ac.knu.cse.countingapp;

import android.app.Service;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.IBinder;
import android.util.Log;
public class MyService extends Service {
    private static final String TAG = MyService.class.getSimpleName();
    Thread thread;
    Thread thread2;
    Boolean threadCondition;
    Boolean threadCondition_Count;
    Boolean ServiceCheck =false;
    public MyService() {
    }


    @Override
    public void onCreate() {
        Log.d(TAG,"Start Service");
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        Log.d(TAG,"Stop Service");
        threadCondition = false;
        threadCondition_Count = false;
        ServiceCheck = false;
        super.onDestroy();

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        /*if(ServiceCheck == false){
        Log.d(TAG,"Start Service");
        }*/
        //threadCondition = false;
        if (intent == null) {
            return Service.START_STICKY;
        } else {
            if (intent.getIntExtra("checkNum", 0) == 1) {
                int interval = intent.getIntExtra("interval",0);
                String str = intent.getStringExtra("str");
                threadCondition = true;
                if(thread != null) {
                    thread.interrupt();
                }
                thread = new Thread() {
                    public void run(){
                        try{
                            while (threadCondition){
                            Log.d(TAG, "Content = " + str +  ", Interval = " +interval+"ms");
                            Thread.sleep(interval);
                            }
                        }catch(InterruptedException e){
                            e.printStackTrace();
                        }
                    }
                };
                thread.start();

            } else if (intent.getIntExtra("checkNum", 0) == 2) {
                threadCondition = false;
            } else if(intent.getIntExtra("checkNum", 0) == 3){
                int interval = intent.getIntExtra("interval",0);
                if(thread2 != null) {
                    thread2.interrupt();
                }
                threadCondition_Count = true;
                    thread2 = new Thread() {
                        public void run(){
                            int count = 0;
                            try{
                                while (threadCondition_Count){
                                    Log.d(TAG, "Count = " + count +  ", Interval = " +interval+"ms");
                                    Thread.sleep(interval);
                                    count++;
                                }
                            }catch(InterruptedException e){
                                e.printStackTrace();
                            }
                        }
                    };
                    thread2.start();



            }else if(intent.getIntExtra("checkNum", 0) == 4){
                threadCondition_Count = false;
            }

            else {
                Log.d(TAG, "잘못 작동중");
            }


        }
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }


}