package kr.ac.knu.cse.countingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    private final static String TAG = MainActivity.class.getSimpleName();
    RadioGroup radioGroup;
    Button serviceOn,serviceOff,CountingOn,CountingOff;
    EditText editText;
    Boolean checkService =false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        editText = findViewById(R.id.editTextContent);
        serviceOn = findViewById(R.id.buttonServiceOn);
        serviceOff = findViewById(R.id.buttonServiceOff);
        CountingOn = findViewById(R.id.buttonCountOn);
        CountingOff = findViewById(R.id.buttonCountOff);
        radioGroup = findViewById(R.id.radioGroup);


        serviceOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkService = true;
                int interval = radioGroup.getCheckedRadioButtonId();
                switch (radioGroup.getCheckedRadioButtonId()){
                    case R.id.radioButton100: {
                        interval = 100;
                        break;
                    }
                    case R.id.radioButton300: {
                        interval = 300;
                        break;
                    }
                    case R.id.radioButton500: {
                        interval = 500;
                        break;
                    }
                    case R.id.radioButton1000:
                    {
                        interval = 1000;
                        break;
                    }
                    default: break;

                }

                String str = editText.getText().toString();
                if(str.isEmpty() != true){


                    int checkNum = 1;

                    Intent intent = new Intent(getApplicationContext(),MyService.class);
                    intent.putExtra("str",str);
                    intent.putExtra("interval",interval);
                    intent.putExtra("checkNum",checkNum);
                    startService(intent);
                }else{

                    int checkNum = 2;
                    Intent intent = new Intent(getApplicationContext(),MyService.class);
                    intent.putExtra("checkNum",checkNum);
                    startService(intent);

                }
            }
        });

        serviceOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(),MyService.class);
                stopService(intent);
                checkService= false;
            }
        });

        CountingOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkService) {
                    int interval = radioGroup.getCheckedRadioButtonId();
                    switch (radioGroup.getCheckedRadioButtonId()){
                        case R.id.radioButton100: {
                            interval = 100;
                            break;
                        }
                        case R.id.radioButton300: {
                            interval = 300;
                            break;
                        }
                        case R.id.radioButton500: {
                            interval = 500;
                            break;
                        }
                        case R.id.radioButton1000:
                        {
                            interval = 1000;
                            break;
                        }
                        default: break;

                    }
                    int checkNum = 3;
                    Intent intent = new Intent(getApplicationContext(),MyService.class);
                    intent.putExtra("checkNum",checkNum);
                    intent.putExtra("interval",interval);
                    startService(intent);

                }
           }
        });

        CountingOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkService) {
                    int checkNum = 4;
                    Intent intent = new Intent(getApplicationContext(), MyService.class);
                    intent.putExtra("checkNum", checkNum);
                    startService(intent);
                }
            }

        });

    }
}